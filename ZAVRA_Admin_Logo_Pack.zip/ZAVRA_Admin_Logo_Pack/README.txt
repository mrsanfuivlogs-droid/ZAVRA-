ZAVRA Admin Panel — Logo Placeholder Pack

Contains individually named SVG UI placeholder tiles for:
Payments: Stripe, PayPal, Wise, Razorpay, UPI, Visa, Mastercard, American Express, RuPay.
Delivery: Shiprocket, Delhivery, India Post, DHL, FedEx, Blue Dart, Ecom Express, Ekart.
Ads: Facebook, Instagram, YouTube, Meta Ads.

IMPORTANT: These are unofficial placeholder tiles with brand names/color cues, NOT official brand artwork and do not mean a service is connected. Replace with provider-approved logos before production and connect services through official APIs.

Suggested folder: public/assets/logos/
